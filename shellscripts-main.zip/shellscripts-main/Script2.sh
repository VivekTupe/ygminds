#!/bin/bash
#This script is to read input from the user/console
echo "Value of a"
read a
echo "Value of b"
read b
echo "Hello value of a is $a and value of b is $b"
echo "This is sample change"
echo "bye"
echo "hi"