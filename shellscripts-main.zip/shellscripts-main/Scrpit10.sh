#!/bin/bash
#This script is to check if and else
a=10
b=20
if [ $a -gt $b ]
then
echo "a is greater than b"
else
echo "a is smaller than b"
fi
