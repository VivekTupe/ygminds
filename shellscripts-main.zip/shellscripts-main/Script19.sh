new script
