#!/bin/bash
#to check the output value of exit status
ls -lrt
echo $?
echo "here if the value is 0 this command is sucessful"
