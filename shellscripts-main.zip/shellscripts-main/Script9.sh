#!/bin/bash
#this is a script for just a if else
a=10
b=20
if [ $a -gt $b ]
then
echo "a is greater than b"
fi
if [ $a -lt $b ]
then
echo "a is less than b"
fi
