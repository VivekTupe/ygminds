#!/bin/sh
for i in 1 2 3 4 5
do
 echo "Looping ... number $i"
done
