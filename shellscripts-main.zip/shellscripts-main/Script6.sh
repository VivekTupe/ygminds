#!/bin/bash
# test of few of the fixed variables
echo "script name: $0"
echo "1st cmdls: $1"
echo "2nd cmdla: $2"
echo "cmdla list: $@"
echo "no of cmdl: $#"
