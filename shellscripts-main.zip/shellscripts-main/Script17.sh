#!/bin/sh
#We have defined a hello world function here
Hello () {
 echo "Hello World"
}
# calling our function
Hello
