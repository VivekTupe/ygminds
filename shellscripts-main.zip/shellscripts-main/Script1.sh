#!/bin/bash
#This is my 1st shell script to print output
echo "Hello All, Welcome to AWS/Devops Class"
echo "Hello, How are you?"
echo "Welcome to Young Minds"
echo "Best class of AWS/DevOps"
echo "Hello Team"
echo "My name is Khan"
echo "Welcome to devops"
echo "We are learning git"
echo "This batch-18"
echo "Good morning"

echo "Welcome to devops"
echo "We are learning git"
echo "This batch-18"
echo "Good morning"
