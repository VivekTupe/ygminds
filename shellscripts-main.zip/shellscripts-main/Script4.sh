#!/bin/bash
#This is creation and calling of shell variable --- defining variables
Class=Young-minds
Batch=13
PROFESSION=AWS/DevOps
echo "Class Name is $Class, Batch number $Batch, We are learning $PROFESSION"
